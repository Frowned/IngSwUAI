﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.Base
{
    public class BaseEntity : BaseAuditEntity
    {
        public int Id { get; set; } 
    }
}
